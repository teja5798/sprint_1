package com.capgemini.bank.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.exceptions.*;

public class AccountDaoImpl implements AccountDao{
	Map<String, Account> userList=new HashMap<String, Account>();
	
	@Override
	public void createAccount(String accountNumber, Account user) {
		// TODO Auto-generated method stub
		try {
			userList.put(accountNumber, user);
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	@Override
	public Account viewAccount(String accountNumber) throws AccountNotFoundException {
		// TODO Auto-generated method stub
		try {
			validateAccount(accountNumber);
			Account user=new Account();
			user=userList.get(accountNumber);
			return user;
		}
		catch(Exception e) {
			throw e;
		}
	}

	@Override
	public boolean addMoney(String accountNumber, int amount) throws AccountNotFoundException{
		// TODO Auto-generated method stub
		try {
			validateAccount(accountNumber);
			Account users=new Account();
			users=userList.get(accountNumber);
			int temp=users.getBalance();
			temp=temp+amount;
			users.setBalance(temp);
			return true;
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	@Override
	public boolean transfer(String accountNumber1, String accountNumber2, int amount) throws SameAccountException,InsuffecientBalanceException,AccountNotFoundException {
		// TODO Auto-generated method stub
			try {
				validateAccount(accountNumber1);
				validateAccount(accountNumber2);
				checkSuffecientBalance(accountNumber1, amount);
				checkSameAccount(accountNumber1,accountNumber2);
				Account user1=userList.get(accountNumber1);
				Account user2=userList.get(accountNumber2);
				int temp1=user1.getBalance();
				int temp2=user2.getBalance();
				temp1=temp1-amount;
				temp2=temp2+amount;
				user1.setBalance(temp1);
				user2.setBalance(temp2);
				return true;
			}
			catch(Exception e)
			{
				throw e;
			}
		
	}
	public void checkSameAccount(String accountNumber1, String accountNumber2) throws SameAccountException{
		// TODO Auto-generated method stub
		try {
			if(accountNumber1.equals(accountNumber2))
			{
				throw new SameAccountException();
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	public void checkSuffecientBalance(String accountNumber1, int amount) throws InsuffecientBalanceException {
		// TODO Auto-generated method stub
		try {
			Account user=userList.get(accountNumber1);
			if(user.getBalance()<amount)
			{
				throw new InsuffecientBalanceException();
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	public void validateAccount(String accountNumber) throws AccountNotFoundException {
		// TODO Auto-generated method stub
		try
		{
			if(!userList.containsKey(accountNumber))
			{
				throw new AccountNotFoundException();
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	@Override
	public HashMap<String, Account> getAllAccounts() {
		// TODO Auto-generated method stub
		try
		{
			return (HashMap<String, Account>) userList;
		}
		catch(Exception e)
		{
			throw e;
		}
	}

}
