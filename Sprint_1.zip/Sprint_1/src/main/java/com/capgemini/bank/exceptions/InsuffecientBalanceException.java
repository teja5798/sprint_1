package com.capgemini.bank.exceptions;

@SuppressWarnings("serial")
public class InsuffecientBalanceException extends Exception{
	public InsuffecientBalanceException() {
		super(" Account Balance is not suffecient for the sender");
	}

}
