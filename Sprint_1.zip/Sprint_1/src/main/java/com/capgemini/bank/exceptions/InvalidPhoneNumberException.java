package com.capgemini.bank.exceptions;
@SuppressWarnings("serial")
public class InvalidPhoneNumberException extends Exception{
	public InvalidPhoneNumberException()
	{
		super("Phone number given is invalid");
	}

}
