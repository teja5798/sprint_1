package com.capgemini.bank.exceptions;
@SuppressWarnings("serial")
public class NameFormatException extends Exception{
	public NameFormatException()
	{
		super("Naming Format is incorrect");
	}

}
