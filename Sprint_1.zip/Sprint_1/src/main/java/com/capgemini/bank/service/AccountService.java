package com.capgemini.bank.service;

import java.util.HashMap;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.exceptions.*;

public interface AccountService {
	public String createAccount(Account user) throws InvalidMailException, InvalidPhoneNumberException;
	public Account viewAccount(String accountNumber) throws AccountNotFoundException;
	public boolean addMoney(String accountNumber, int amount) throws AccountNotFoundException;
	public boolean transfer(String accountNumber1,String accountNumber2, int amount) throws InsuffecientBalanceException, AccountNotFoundException, SameAccountException;
	public HashMap<String, Account> getAllAccounts();
}
