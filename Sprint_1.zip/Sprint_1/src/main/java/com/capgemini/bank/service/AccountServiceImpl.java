package com.capgemini.bank.service;

import java.util.HashMap;
import java.util.Random;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.dao.*;
import com.capgemini.bank.exceptions.*;
public class AccountServiceImpl extends Validator implements AccountService{
	AccountDao dao=new AccountDaoImpl();
	Validator valid=new Validator();
	@Override
	public String createAccount(Account user) throws InvalidMailException, InvalidPhoneNumberException{
		// TODO Auto-generated method stub
		String accountNumber=null;
		try 
		{
			valid.validator(user);
			Random rand=new Random();
			int num=rand.nextInt(9000000)+1000000;
			accountNumber=String.valueOf(num);
			dao.createAccount(accountNumber, user);
		}
		catch(Exception e)
		{
			accountNumber=null;
			throw e;
		}
		return accountNumber;
		
	}


	@Override
	public Account viewAccount(String accountNumber) throws AccountNotFoundException{

		try
		{
			return dao.viewAccount(accountNumber);
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	@Override
	public boolean addMoney(String accountNumber, int amount) throws AccountNotFoundException {
		// TODO Auto-generated method stub
		try
		{
			return dao.addMoney(accountNumber, amount);
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	@Override
	public boolean transfer(String accountNumber1, String accountNumber2, int amount) throws InsuffecientBalanceException, AccountNotFoundException,SameAccountException {
		// TODO Auto-generated method stub
		try {
			return dao.transfer(accountNumber1, accountNumber2, amount);
			
			}
		catch(Exception e)
		{
			throw e;
		}
		
	}


	@Override
	public HashMap<String, Account> getAllAccounts() {
		// TODO Auto-generated method stub
		try {
			return dao.getAllAccounts();
		}
		catch(Exception e)
		{
			throw e;
		}
	}

}
