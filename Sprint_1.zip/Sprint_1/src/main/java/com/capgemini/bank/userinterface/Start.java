package com.capgemini.bank.userinterface;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.service.AccountServiceImpl;
public class Start {
	static AccountServiceImpl service=new AccountServiceImpl();
	public static void main(String[] args)
	{
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		boolean result;
		int choice;
		while(true)
		{
			
		    System.out.println("01. Create an account");
			System.out.println("02. Add balance to account");
			System.out.println("03. Show details");
			System.out.println("04. Transfer money to other account");
			System.out.println("05. Show all accounts available");
			System.out.println("06. Exit from service");
			System.out.print("Enter your choice : ");
			choice=input.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Account Creation");
				try
				{
					Account user=new Account();
					System.out.println("Enter your name:");
					user.setName(input.next());
					System.out.println("Enter your phone number:");
					user.setPhoneNumber(input.nextLong());
					System.out.println("Enter your email:");
					user.setEmailid(input.next());
					user.setBalance(0);
					String AccountNumber=service.createAccount(user);
					System.out.println("Your Account Number is : "+AccountNumber);
					
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 2:
				result=false;
				System.out.println("Adding Money to the Account");
				try {
					System.out.println("Enter the account number to add money:");
					String AccountNumber=input.next();
					System.out.println("Enter the amount to be added to the account:");
					int Amount=input.nextInt();
					result=service.addMoney(AccountNumber, Amount);
					if(result) {
						System.out.println("Money successfully to the wallet");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 3:
				System.out.println("View Account Details");
				try
				{
					System.out.println("Enter the Account Number");
					String AccountNumber=input.next();
					Account user=service.viewAccount(AccountNumber);
					System.out.println("Name="+user.getName()+"\nPhone="+user.getPhoneNumber()+"\nEmail="+user.getEmailid()+"\nBalance="+user.getBalance());
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 4:
				result=false;
				System.out.println("Money Transfer");
				try
				{
					System.out.println("Enter the sender Account Number");
					String SenderAccountNumber=input.next();
					System.out.println("Enter the Reciever Account Number");
					String RecieverAccountNumber=input.next();
					System.out.println("Enter the amount to be transferred");
					int TransferAmount=input.nextInt();
					result=service.transfer(SenderAccountNumber, RecieverAccountNumber, TransferAmount);
					if(result) {
						System.out.println("Money transfered successfully");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 5:
				try
				{
					Map<String, Account> map=new HashMap<String, Account>();
					map=service.getAllAccounts();
					if(!map.isEmpty())
					{

						Set<Entry<String, Account>> set=map.entrySet();
						Iterator<Entry<String, Account>> i=set.iterator();
				        while(i.hasNext())
						{
							Map.Entry<String, Account> me=(Map.Entry<String, Account>)i.next();
							Account account=me.getValue();
							System.out.println("Account Number: "+me.getKey()+"\nName: "+account.getName());
						}
					}
					else
					{
						System.out.println("No Accounts Found");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 6:
				System.exit(0);
			default:
				System.out.println("Enter choices from 1 to 6 only");
				break;
			}
		}
	}

}
